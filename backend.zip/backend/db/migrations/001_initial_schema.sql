-- ============================================================
-- Migration 001: Initial Schema
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─────────────────────────────────────────
-- USERS (auth + account type only)
-- ─────────────────────────────────────────
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email           VARCHAR(255) NOT NULL UNIQUE,
  password_hash   TEXT NOT NULL,
  username        VARCHAR(50)  NOT NULL UNIQUE,
  account_type    VARCHAR(20)  NOT NULL CHECK (account_type IN ('personal', 'business', 'both')),
  is_verified     BOOLEAN      NOT NULL DEFAULT FALSE,
  is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
  last_login_at   TIMESTAMP,
  created_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email    ON users(email);
CREATE INDEX idx_users_username ON users(username);

-- ─────────────────────────────────────────
-- PERSONAL PROFILES
-- ─────────────────────────────────────────
CREATE TABLE profiles (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  full_name         VARCHAR(100),
  phone_number      VARCHAR(20),
  whatsapp_number   VARCHAR(20),
  location          VARCHAR(150),
  bio               TEXT,
  card_theme        VARCHAR(50)  DEFAULT 'default',
  profile_image_url TEXT,
  cover_image_url   TEXT,
  is_public         BOOLEAN      NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMP    NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMP    NOT NULL DEFAULT NOW(),
  UNIQUE (user_id)  -- one personal profile per user
);

CREATE INDEX idx_profiles_user_id ON profiles(user_id);

-- ─────────────────────────────────────────
-- BUSINESS PROFILES
-- ─────────────────────────────────────────
CREATE TABLE business_profiles (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  full_name         VARCHAR(100),
  job_title         VARCHAR(100),
  company_name      VARCHAR(150),
  phone_number      VARCHAR(20),
  whatsapp_number   VARCHAR(20),
  location          VARCHAR(150),
  bio               TEXT,
  card_theme        VARCHAR(50)  DEFAULT 'default',
  profile_image_url TEXT,
  cover_image_url   TEXT,
  is_public         BOOLEAN      NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMP    NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMP    NOT NULL DEFAULT NOW(),
  UNIQUE (user_id)  -- one business profile per user
);

CREATE INDEX idx_business_profiles_user_id ON business_profiles(user_id);

-- ─────────────────────────────────────────
-- PROFILE LINKS (shared by both profile types)
-- ─────────────────────────────────────────
CREATE TABLE profile_links (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id    UUID        NOT NULL,
  profile_type  VARCHAR(10) NOT NULL CHECK (profile_type IN ('personal', 'business')),
  label         VARCHAR(50) NOT NULL,   -- e.g. "LinkedIn", "Website"
  url           TEXT        NOT NULL,
  icon          VARCHAR(50),            -- icon slug e.g. "linkedin", "globe"
  display_order INT         NOT NULL DEFAULT 0,
  created_at    TIMESTAMP   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_profile_links_profile ON profile_links(profile_id, profile_type);

-- ─────────────────────────────────────────
-- CONNECTIONS (social contacts)
-- ─────────────────────────────────────────
CREATE TABLE connections (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status        VARCHAR(10) NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending', 'accepted', 'declined', 'blocked')),
  decline_count INT       NOT NULL DEFAULT 0,
  declined_at   TIMESTAMP,
  created_at    TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE (requester_id, recipient_id),
  CHECK (requester_id != recipient_id)
);

CREATE INDEX idx_connections_requester ON connections(requester_id, status);
CREATE INDEX idx_connections_recipient ON connections(recipient_id, status);

-- ─────────────────────────────────────────
-- REFRESH TOKENS (for mobile + web sessions)
-- ─────────────────────────────────────────
CREATE TABLE refresh_tokens (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  device_info TEXT,           -- "iPhone 14 / iOS 17"
  ip_address  VARCHAR(45),
  expires_at  TIMESTAMP NOT NULL,
  revoked_at  TIMESTAMP,
  created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);

-- ─────────────────────────────────────────
-- AUTO-UPDATE updated_at TRIGGER
-- ─────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_business_profiles_updated_at
  BEFORE UPDATE ON business_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_connections_updated_at
  BEFORE UPDATE ON connections FOR EACH ROW EXECUTE FUNCTION update_updated_at();
