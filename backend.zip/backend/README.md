# Social Platform Backend

Node.js + Express + PostgreSQL backend.
Compatible with web, React Native, and Flutter clients.
