require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const rateLimit = require('express-rate-limit');
const path    = require('path');
const routes  = require('./routes/index');

const app = express();

// ── Security headers
app.use(helmet());

// ── CORS — allow web and mobile clients
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
  methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// ── Body parsers
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Serve local uploads in dev
if (process.env.STORAGE_PROVIDER !== 's3') {
  app.use('/uploads', express.static(
    path.resolve(process.env.LOCAL_UPLOAD_PATH || './uploads')
  ));
}

// ── Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api', limiter);

// ── Routes
app.use('/api', routes);

// ── Health check
app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date() }));

// ── 404
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));

// ── Global error handler
app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'File too large (max 5MB)' });
  }
  res.status(500).json({ error: err.message || 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

module.exports = app;
