const express = require('express');
const router = express.Router();
const { authenticate, optionalAuth } = require('../middleware/auth');
const { upload } = require('../config/storage');
const authCtrl = require('../controllers/auth.controller');
const profileCtrl = require('../controllers/profile.controller');
const connectCtrl = require('../controllers/connections.controller');

const profileUpload = upload.fields([
  { name: 'profile_image', maxCount: 1 },
  { name: 'cover_image',   maxCount: 1 },
]);

// ── AUTH ──────────────────────────────────────
router.post('/auth/register', authCtrl.register);
router.post('/auth/login',    authCtrl.login);
router.post('/auth/refresh',  authCtrl.refresh);
router.post('/auth/logout',   authCtrl.logout);

// ── PERSONAL PROFILES ─────────────────────────
router.get('/profiles/me',       authenticate, profileCtrl.getMyProfile);
router.patch('/profiles/me',     authenticate, profileUpload, profileCtrl.updateMyProfile);
router.get('/profiles/:username', optionalAuth, profileCtrl.getProfileByUsername);

// ── BUSINESS PROFILES ─────────────────────────
router.get('/business-profiles/me',       authenticate, profileCtrl.getMyBusinessProfile);
router.patch('/business-profiles/me',     authenticate, profileUpload, profileCtrl.updateMyBusinessProfile);
router.get('/business-profiles/:username', optionalAuth, profileCtrl.getBusinessProfileByUsername);

// ── PROFILE LINKS (shared endpoint) ───────────
router.put('/profiles/me/links', authenticate, profileCtrl.updateProfileLinks);

// ── SEARCH ────────────────────────────────────
router.get('/users/search', authenticate, connectCtrl.searchUsers);

// ── CONNECTIONS / CONTACT BOOK ────────────────
router.get('/connections',          authenticate, connectCtrl.getMyConnections);
router.get('/connections/pending',  authenticate, connectCtrl.getPendingRequests);
router.post('/connections',         authenticate, connectCtrl.sendRequest);
router.patch('/connections/:id',    authenticate, connectCtrl.respondToRequest);
router.delete('/connections/:id',   authenticate, connectCtrl.removeConnection);
router.post('/connections/:id/block', authenticate, connectCtrl.blockUser);

module.exports = router;
