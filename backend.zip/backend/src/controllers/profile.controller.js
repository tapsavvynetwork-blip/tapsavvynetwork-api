const db = require('../config/db');
const { getFileUrl } = require('../config/storage');

// ── PERSONAL PROFILE ──────────────────────────────────────────

// GET /api/profiles/:username  (public, optionally authenticated)
const getProfileByUsername = async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT
         u.username, u.account_type,
         p.id, p.full_name, p.phone_number, p.whatsapp_number,
         p.location, p.bio, p.card_theme, p.profile_image_url, p.cover_image_url,
         p.is_public
       FROM users u
       JOIN profiles p ON p.user_id = u.id
       WHERE u.username = $1`,
      [req.params.username]
    );
    if (!rows.length) return res.status(404).json({ error: 'Profile not found' });

    const profile = rows[0];
    if (!profile.is_public && req.user?.id !== profile.user_id) {
      return res.status(403).json({ error: 'This profile is private' });
    }

    // Attach links
    const { rows: links } = await db.query(
      `SELECT label, url, icon, display_order FROM profile_links
       WHERE profile_id = $1 AND profile_type = 'personal'
       ORDER BY display_order`,
      [profile.id]
    );
    profile.links = links;

    res.json({ profile });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
};

// GET /api/profiles/me  (own profile)
const getMyProfile = async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT p.*, u.username, u.email, u.account_type
       FROM profiles p
       JOIN users u ON u.id = p.user_id
       WHERE p.user_id = $1`,
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Profile not found' });

    const profile = rows[0];
    const { rows: links } = await db.query(
      `SELECT id, label, url, icon, display_order FROM profile_links
       WHERE profile_id = $1 AND profile_type = 'personal'
       ORDER BY display_order`,
      [profile.id]
    );
    profile.links = links;
    res.json({ profile });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
};

// PATCH /api/profiles/me
const updateMyProfile = async (req, res) => {
  const allowedFields = [
    'full_name', 'phone_number', 'whatsapp_number',
    'location', 'bio', 'card_theme', 'is_public'
  ];
  const updates = {};
  allowedFields.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });

  if (!Object.keys(updates).length && !req.files?.profile_image && !req.files?.cover_image) {
    return res.status(400).json({ error: 'No fields to update' });
  }

  try {
    // Handle image uploads
    if (req.files?.profile_image?.[0]) {
      updates.profile_image_url = getFileUrl(req, req.files.profile_image[0]);
    }
    if (req.files?.cover_image?.[0]) {
      updates.cover_image_url = getFileUrl(req, req.files.cover_image[0]);
    }

    const keys = Object.keys(updates);
    const values = Object.values(updates);
    const setClause = keys.map((k, i) => `${k} = $${i + 1}`).join(', ');

    const { rows } = await db.query(
      `UPDATE profiles SET ${setClause}, updated_at = NOW()
       WHERE user_id = $${keys.length + 1}
       RETURNING *`,
      [...values, req.user.id]
    );
    res.json({ profile: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Profile update failed', detail: err.message });
  }
};

// ── BUSINESS PROFILE ──────────────────────────────────────────

// GET /api/business-profiles/:username
const getBusinessProfileByUsername = async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT
         u.username, u.account_type,
         bp.id, bp.full_name, bp.job_title, bp.company_name,
         bp.phone_number, bp.whatsapp_number, bp.location,
         bp.bio, bp.card_theme, bp.profile_image_url, bp.cover_image_url,
         bp.is_public
       FROM users u
       JOIN business_profiles bp ON bp.user_id = u.id
       WHERE u.username = $1`,
      [req.params.username]
    );
    if (!rows.length) return res.status(404).json({ error: 'Business profile not found' });

    const profile = rows[0];
    const { rows: links } = await db.query(
      `SELECT label, url, icon, display_order FROM profile_links
       WHERE profile_id = $1 AND profile_type = 'business'
       ORDER BY display_order`,
      [profile.id]
    );
    profile.links = links;
    res.json({ profile });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch business profile' });
  }
};

// GET /api/business-profiles/me
const getMyBusinessProfile = async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT * FROM business_profiles WHERE user_id = $1',
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Business profile not found' });

    const profile = rows[0];
    const { rows: links } = await db.query(
      `SELECT id, label, url, icon, display_order FROM profile_links
       WHERE profile_id = $1 AND profile_type = 'business'
       ORDER BY display_order`,
      [profile.id]
    );
    profile.links = links;
    res.json({ profile });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch business profile' });
  }
};

// PATCH /api/business-profiles/me
const updateMyBusinessProfile = async (req, res) => {
  const allowedFields = [
    'full_name', 'job_title', 'company_name', 'phone_number',
    'whatsapp_number', 'location', 'bio', 'card_theme', 'is_public'
  ];
  const updates = {};
  allowedFields.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });

  try {
    if (req.files?.profile_image?.[0]) {
      updates.profile_image_url = getFileUrl(req, req.files.profile_image[0]);
    }
    if (req.files?.cover_image?.[0]) {
      updates.cover_image_url = getFileUrl(req, req.files.cover_image[0]);
    }

    const keys = Object.keys(updates);
    if (!keys.length) return res.status(400).json({ error: 'No fields to update' });

    const values = Object.values(updates);
    const setClause = keys.map((k, i) => `${k} = $${i + 1}`).join(', ');

    const { rows } = await db.query(
      `UPDATE business_profiles SET ${setClause}, updated_at = NOW()
       WHERE user_id = $${keys.length + 1}
       RETURNING *`,
      [...values, req.user.id]
    );
    res.json({ profile: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Business profile update failed' });
  }
};

// ── PROFILE LINKS ─────────────────────────────────────────────

// PUT /api/profiles/me/links  (replaces all links at once)
const updateProfileLinks = async (req, res) => {
  const { links, profile_type = 'personal' } = req.body;
  if (!Array.isArray(links)) return res.status(400).json({ error: 'Links must be an array' });

  const client = await db.getClient();
  try {
    await client.query('BEGIN');

    // Find the profile id
    const table = profile_type === 'business' ? 'business_profiles' : 'profiles';
    const { rows: profileRows } = await client.query(
      `SELECT id FROM ${table} WHERE user_id = $1`, [req.user.id]
    );
    if (!profileRows.length) throw new Error('Profile not found');
    const profileId = profileRows[0].id;

    // Replace all links
    await client.query(
      'DELETE FROM profile_links WHERE profile_id = $1 AND profile_type = $2',
      [profileId, profile_type]
    );
    for (let i = 0; i < links.length; i++) {
      const { label, url, icon } = links[i];
      await client.query(
        `INSERT INTO profile_links (profile_id, profile_type, label, url, icon, display_order)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [profileId, profile_type, label, url, icon || null, i]
      );
    }

    await client.query('COMMIT');
    res.json({ message: 'Links updated', count: links.length });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Failed to update links', detail: err.message });
  } finally {
    client.release();
  }
};

module.exports = {
  getProfileByUsername,
  getMyProfile,
  updateMyProfile,
  getBusinessProfileByUsername,
  getMyBusinessProfile,
  updateMyBusinessProfile,
  updateProfileLinks,
};
