const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const db = require('../config/db');

const generateTokens = (userId) => {
  const accessToken = jwt.sign(
    { sub: userId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_ACCESS_EXPIRES || '15m' }
  );
  const refreshToken = crypto.randomBytes(40).toString('hex');
  return { accessToken, refreshToken };
};

// POST /api/auth/register
const register = async (req, res) => {
  const { email, password, username, account_type } = req.body;
  try {
    const existing = await db.query(
      'SELECT id FROM users WHERE email = $1 OR username = $2',
      [email, username]
    );
    if (existing.rows.length) {
      return res.status(409).json({ error: 'Email or username already taken' });
    }

    const password_hash = await bcrypt.hash(password, 12);
    const { rows } = await db.query(
      `INSERT INTO users (email, password_hash, username, account_type)
       VALUES ($1, $2, $3, $4) RETURNING id, email, username, account_type`,
      [email, password_hash, username, account_type || 'personal']
    );
    const user = rows[0];

    // Auto-create empty profile row(s) based on account_type
    if (['personal', 'both'].includes(user.account_type)) {
      await db.query('INSERT INTO profiles (user_id) VALUES ($1)', [user.id]);
    }
    if (['business', 'both'].includes(user.account_type)) {
      await db.query('INSERT INTO business_profiles (user_id) VALUES ($1)', [user.id]);
    }

    const { accessToken, refreshToken } = generateTokens(user.id);
    const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await db.query(
      'INSERT INTO refresh_tokens (user_id, token_hash, device_info, ip_address, expires_at) VALUES ($1,$2,$3,$4,$5)',
      [user.id, tokenHash, req.headers['user-agent'], req.ip, expiresAt]
    );

    res.status(201).json({ user, accessToken, refreshToken });
  } catch (err) {
    res.status(500).json({ error: 'Registration failed', detail: err.message });
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  const { email, password, device_info } = req.body;
  try {
    const { rows } = await db.query(
      'SELECT id, email, username, account_type, password_hash FROM users WHERE email = $1 AND is_active = TRUE',
      [email]
    );
    if (!rows.length) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const user = rows[0];
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    await db.query('UPDATE users SET last_login_at = NOW() WHERE id = $1', [user.id]);

    const { accessToken, refreshToken } = generateTokens(user.id);
    const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await db.query(
      'INSERT INTO refresh_tokens (user_id, token_hash, device_info, ip_address, expires_at) VALUES ($1,$2,$3,$4,$5)',
      [user.id, tokenHash, device_info || req.headers['user-agent'], req.ip, expiresAt]
    );

    const { password_hash, ...safeUser } = user;
    res.json({ user: safeUser, accessToken, refreshToken });
  } catch (err) {
    res.status(500).json({ error: 'Login failed' });
  }
};

// POST /api/auth/refresh
const refresh = async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: 'Refresh token required' });

  const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
  try {
    const { rows } = await db.query(
      `SELECT rt.user_id FROM refresh_tokens rt
       WHERE rt.token_hash = $1
         AND rt.revoked_at IS NULL
         AND rt.expires_at > NOW()`,
      [tokenHash]
    );
    if (!rows.length) return res.status(401).json({ error: 'Invalid or expired refresh token' });

    // Rotate: revoke old, issue new
    await db.query('UPDATE refresh_tokens SET revoked_at = NOW() WHERE token_hash = $1', [tokenHash]);
    const userId = rows[0].user_id;
    const { accessToken, refreshToken: newRefresh } = generateTokens(userId);
    const newHash = crypto.createHash('sha256').update(newRefresh).digest('hex');
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await db.query(
      'INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1,$2,$3)',
      [userId, newHash, expiresAt]
    );

    res.json({ accessToken, refreshToken: newRefresh });
  } catch (err) {
    res.status(500).json({ error: 'Token refresh failed' });
  }
};

// POST /api/auth/logout
const logout = async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    await db.query('UPDATE refresh_tokens SET revoked_at = NOW() WHERE token_hash = $1', [tokenHash]);
  }
  res.json({ message: 'Logged out' });
};

module.exports = { register, login, refresh, logout };
