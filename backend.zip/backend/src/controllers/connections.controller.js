const db = require('../config/db');

// POST /api/connections  — send a connect request
const sendRequest = async (req, res) => {
  const { recipient_id } = req.body;
  const requesterId = req.user.id;

  if (requesterId === recipient_id) {
    return res.status(400).json({ error: 'Cannot connect with yourself' });
  }

  try {
    // Check if recipient exists
    const { rows: userRows } = await db.query('SELECT id FROM users WHERE id = $1', [recipient_id]);
    if (!userRows.length) return res.status(404).json({ error: 'User not found' });

    // Check existing connection in BOTH directions
    const { rows: existing } = await db.query(
      `SELECT * FROM connections
       WHERE (requester_id = $1 AND recipient_id = $2)
          OR (requester_id = $2 AND recipient_id = $1)`,
      [requesterId, recipient_id]
    );

    if (existing.length) {
      const conn = existing[0];
      if (conn.status === 'accepted') return res.status(409).json({ error: 'Already connected' });
      if (conn.status === 'pending')  return res.status(409).json({ error: 'Request already pending' });
      if (conn.status === 'blocked')  return res.status(403).json({ error: 'Cannot connect' });

      // Was declined — check cooldown (30 days) and max attempts (3)
      if (conn.status === 'declined') {
        if (conn.decline_count >= 3) {
          return res.status(403).json({ error: 'Connection not available' });
        }
        const cooldownEnd = new Date(conn.declined_at);
        cooldownEnd.setDate(cooldownEnd.getDate() + 30);
        if (new Date() < cooldownEnd) {
          return res.status(429).json({ error: 'Please wait before sending another request' });
        }
        // Reset to pending
        const { rows } = await db.query(
          `UPDATE connections SET status = 'pending', updated_at = NOW()
           WHERE id = $1 RETURNING *`,
          [conn.id]
        );
        return res.status(201).json({ connection: rows[0] });
      }
    }

    const { rows } = await db.query(
      `INSERT INTO connections (requester_id, recipient_id, status)
       VALUES ($1, $2, 'pending') RETURNING *`,
      [requesterId, recipient_id]
    );
    res.status(201).json({ connection: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to send request', detail: err.message });
  }
};

// PATCH /api/connections/:id  — accept or decline
const respondToRequest = async (req, res) => {
  const { status } = req.body; // 'accepted' | 'declined'
  if (!['accepted', 'declined'].includes(status)) {
    return res.status(400).json({ error: 'Status must be accepted or declined' });
  }

  try {
    const { rows } = await db.query(
      `SELECT * FROM connections WHERE id = $1 AND recipient_id = $2 AND status = 'pending'`,
      [req.params.id, req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Pending request not found' });

    const updateQuery = status === 'declined'
      ? `UPDATE connections
         SET status = 'declined', declined_at = NOW(),
             decline_count = decline_count + 1, updated_at = NOW()
         WHERE id = $1 RETURNING *`
      : `UPDATE connections SET status = $2, updated_at = NOW() WHERE id = $1 RETURNING *`;

    const params = status === 'declined' ? [req.params.id] : [req.params.id, status];
    const { rows: updated } = await db.query(updateQuery, params);
    res.json({ connection: updated[0] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update connection' });
  }
};

// DELETE /api/connections/:id  — remove or cancel
const removeConnection = async (req, res) => {
  try {
    const { rows } = await db.query(
      `DELETE FROM connections
       WHERE id = $1 AND (requester_id = $2 OR recipient_id = $2)
       RETURNING id`,
      [req.params.id, req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Connection not found' });
    res.json({ message: 'Connection removed' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to remove connection' });
  }
};

// POST /api/connections/:id/block
const blockUser = async (req, res) => {
  try {
    const { rows } = await db.query(
      `UPDATE connections SET status = 'blocked', updated_at = NOW()
       WHERE id = $1 AND (requester_id = $2 OR recipient_id = $2)
       RETURNING *`,
      [req.params.id, req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Connection not found' });
    res.json({ connection: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Block failed' });
  }
};

// GET /api/connections  — my contact book (accepted connections)
const getMyConnections = async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;

  try {
    const { rows } = await db.query(
      `SELECT
         c.id AS connection_id,
         c.created_at AS connected_at,
         CASE WHEN c.requester_id = $1 THEN c.recipient_id ELSE c.requester_id END AS user_id,
         u.username,
         p.full_name, p.profile_image_url,
         bp.full_name AS business_name, bp.job_title, bp.company_name
       FROM connections c
       JOIN users u ON u.id = CASE WHEN c.requester_id = $1 THEN c.recipient_id ELSE c.requester_id END
       LEFT JOIN profiles p ON p.user_id = u.id
       LEFT JOIN business_profiles bp ON bp.user_id = u.id
       WHERE (c.requester_id = $1 OR c.recipient_id = $1)
         AND c.status = 'accepted'
       ORDER BY c.updated_at DESC
       LIMIT $2 OFFSET $3`,
      [req.user.id, limit, offset]
    );
    res.json({ connections: rows, page: Number(page), limit: Number(limit) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch connections' });
  }
};

// GET /api/connections/pending  — incoming pending requests
const getPendingRequests = async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT c.id, c.created_at,
              u.id AS requester_user_id, u.username,
              p.full_name, p.profile_image_url
       FROM connections c
       JOIN users u ON u.id = c.requester_id
       LEFT JOIN profiles p ON p.user_id = u.id
       WHERE c.recipient_id = $1 AND c.status = 'pending'
       ORDER BY c.created_at DESC`,
      [req.user.id]
    );
    res.json({ requests: rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch requests' });
  }
};

// GET /api/users/search?q=...  — search with connection status
const searchUsers = async (req, res) => {
  const { q, page = 1, limit = 20 } = req.query;
  if (!q?.trim()) return res.status(400).json({ error: 'Search query required' });

  const offset = (page - 1) * limit;
  const searchTerm = `%${q.trim()}%`;

  try {
    const { rows } = await db.query(
      `SELECT
         u.id, u.username, u.account_type,
         p.full_name, p.profile_image_url, p.location,
         bp.full_name AS business_name, bp.job_title, bp.company_name,
         -- connection status from current user's perspective
         c.status AS connection_status,
         c.id AS connection_id,
         CASE WHEN c.requester_id = $1 THEN 'sent' ELSE 'received' END AS direction
       FROM users u
       LEFT JOIN profiles p ON p.user_id = u.id
       LEFT JOIN business_profiles bp ON bp.user_id = u.id
       LEFT JOIN connections c ON (
         (c.requester_id = $1 AND c.recipient_id = u.id) OR
         (c.requester_id = u.id AND c.recipient_id = $1)
       )
       WHERE u.id != $1
         AND u.is_active = TRUE
         AND (
           u.username ILIKE $2
           OR p.full_name ILIKE $2
           OR bp.full_name ILIKE $2
           OR bp.company_name ILIKE $2
         )
         AND COALESCE(c.status, '') != 'blocked'
       ORDER BY
         CASE WHEN c.status = 'accepted' THEN 0 ELSE 1 END,
         u.username
       LIMIT $3 OFFSET $4`,
      [req.user.id, searchTerm, limit, offset]
    );
    res.json({ users: rows, page: Number(page), limit: Number(limit) });
  } catch (err) {
    res.status(500).json({ error: 'Search failed', detail: err.message });
  }
};

module.exports = {
  sendRequest,
  respondToRequest,
  removeConnection,
  blockUser,
  getMyConnections,
  getPendingRequests,
  searchUsers,
};
