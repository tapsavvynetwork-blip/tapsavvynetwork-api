const jwt = require('jsonwebtoken');
const db = require('../config/db');

/**
 * Protects routes — verifies the Bearer token and attaches req.user.
 */
const authenticate = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);

    // Confirm user still exists and is active
    const { rows } = await db.query(
      'SELECT id, email, username, account_type FROM users WHERE id = $1 AND is_active = TRUE',
      [payload.sub]
    );
    if (!rows.length) {
      return res.status(401).json({ error: 'User not found or deactivated' });
    }

    req.user = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
};

/**
 * Optionally authenticates — attaches req.user if token present, continues if not.
 * Use on public endpoints that behave differently for logged-in users.
 */
const optionalAuth = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) return next();
  try {
    const payload = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET);
    const { rows } = await db.query('SELECT id, username FROM users WHERE id = $1', [payload.sub]);
    if (rows.length) req.user = rows[0];
  } catch (_) {}
  next();
};

module.exports = { authenticate, optionalAuth };
