const multer = require('multer');
const multerS3 = require('multer-s3');
const { S3Client } = require('@aws-sdk/client-s3');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

const fileFilter = (req, file, cb) => {
  if (ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Only JPEG, PNG, and WebP images are allowed'), false);
  }
};

// ── S3 Storage ─────────────────────────────────
const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const s3Storage = multerS3({
  s3: s3Client,
  bucket: process.env.S3_BUCKET_NAME,
  contentType: multerS3.AUTO_CONTENT_TYPE,
  key: (req, file, cb) => {
    const folder = file.fieldname === 'cover_image' ? 'covers' : 'avatars';
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${folder}/${uuidv4()}${ext}`);
  },
  acl: 'public-read',
});

// ── Local Storage (dev fallback) ───────────────
const localStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, process.env.LOCAL_UPLOAD_PATH || './uploads');
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${uuidv4()}${ext}`);
  },
});

const storage = process.env.STORAGE_PROVIDER === 's3' ? s3Storage : localStorage;

const upload = multer({ storage, fileFilter, limits: { fileSize: MAX_FILE_SIZE } });

/**
 * Get the public URL for an uploaded file.
 * For S3: returns the CDN/S3 URL from multer-s3.
 * For local: builds a URL from your server base.
 */
const getFileUrl = (req, file) => {
  if (process.env.STORAGE_PROVIDER === 's3') {
    return file.location; // multer-s3 sets this automatically
  }
  return `${req.protocol}://${req.get('host')}/uploads/${file.filename}`;
};

module.exports = { upload, getFileUrl };
