# API Reference

Base URL: `https://yourapi.com/api`

All protected endpoints require:
```
Authorization: Bearer <accessToken>
```

---

## Auth

| Method | Endpoint          | Body                                         | Auth |
|--------|-------------------|----------------------------------------------|------|
| POST   | /auth/register    | email, password, username, account_type      | No   |
| POST   | /auth/login       | email, password, device_info?                | No   |
| POST   | /auth/refresh     | refreshToken                                 | No   |
| POST   | /auth/logout      | refreshToken?                                | No   |

`account_type` values: `personal` | `business` | `both`

---

## Personal Profile

| Method | Endpoint               | Notes                              | Auth |
|--------|------------------------|------------------------------------|------|
| GET    | /profiles/me           | Own profile with links             | Yes  |
| PATCH  | /profiles/me           | multipart/form-data, any fields    | Yes  |
| GET    | /profiles/:username    | Public profile view                | No*  |

*Authenticated users see connection status too.

PATCH body fields (all optional):
- `full_name`, `phone_number`, `whatsapp_number`, `location`, `bio`, `card_theme`, `is_public`
- `profile_image` (file), `cover_image` (file)

---

## Business Profile

| Method | Endpoint                      | Notes                           | Auth |
|--------|-------------------------------|---------------------------------|------|
| GET    | /business-profiles/me         | Own business profile            | Yes  |
| PATCH  | /business-profiles/me         | multipart/form-data             | Yes  |
| GET    | /business-profiles/:username  | Public business profile view    | No*  |

Extra PATCH fields: `job_title`, `company_name`

---

## Links (Personal & Business)

| Method | Endpoint           | Body                              | Auth |
|--------|--------------------|-----------------------------------|------|
| PUT    | /profiles/me/links | links[] array, profile_type       | Yes  |

Body:
```json
{
  "profile_type": "personal",
  "links": [
    { "label": "LinkedIn", "url": "https://...", "icon": "linkedin" },
    { "label": "Website",  "url": "https://...", "icon": "globe" }
  ]
}
```
This replaces all links in one call. Order is preserved.

---

## Search

| Method | Endpoint         | Query Params           | Auth |
|--------|------------------|------------------------|------|
| GET    | /users/search    | q, page?, limit?       | Yes  |

Response includes `connection_status` per user:
- `null` → show Connect button
- `pending` + `direction: sent` → show Pending
- `pending` + `direction: received` → show Accept/Decline
- `accepted` → show Connected
- `blocked` → hidden from results

---

## Connections (Contact Book)

| Method | Endpoint                   | Body / Notes                    | Auth |
|--------|----------------------------|---------------------------------|------|
| GET    | /connections               | page?, limit? — contact book    | Yes  |
| GET    | /connections/pending       | Incoming requests inbox         | Yes  |
| POST   | /connections               | { recipient_id }                | Yes  |
| PATCH  | /connections/:id           | { status: accepted/declined }   | Yes  |
| DELETE | /connections/:id           | Remove or cancel                | Yes  |
| POST   | /connections/:id/block     | Block user                      | Yes  |

---

## Token Flow (Mobile & Web)

```
1. Login → receive accessToken (15min) + refreshToken (30 days)
2. Use accessToken in Authorization header
3. On 401 TOKEN_EXPIRED → POST /auth/refresh with refreshToken
4. Receive new accessToken + refreshToken (rotation)
5. On logout → POST /auth/logout to revoke refreshToken
```

---

## Image Upload (multipart/form-data)

```
PATCH /api/profiles/me
Content-Type: multipart/form-data

Fields:
  profile_image  (file, max 5MB, jpg/png/webp)
  cover_image    (file, max 5MB, jpg/png/webp)
  full_name      (text)
  bio            (text)
  ... other profile fields
```
